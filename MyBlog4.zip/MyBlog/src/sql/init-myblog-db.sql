-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 05-11-2007 a las 01:34:37
-- Versión del servidor: 5.0.45
-- Versión de PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `myblog`
-- 
DROP DATABASE `myblog`;
CREATE DATABASE `myblog` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `myblog`;

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `blog_entry`
-- 

DROP TABLE IF EXISTS `blog_entry`;
CREATE TABLE IF NOT EXISTS `blog_entry` (
  `eid` int(11) NOT NULL auto_increment,
  `title` varchar(200) default NULL,
  `body` varchar(1000) default NULL,
  PRIMARY KEY  (`eid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `blog_entry`
-- 

INSERT INTO `blog_entry` (`eid`, `title`, `body`) VALUES 
(1, 'Esto es el primer post del blog', 'Veamos..este es un primer ejemplo...'),
(2, 'Esta es la segunda entrada', 'Se va la segunda ...segunda...');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `comment`
-- 

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `cid` int(11) NOT NULL auto_increment,
  `author` varchar(200) default NULL,
  `message` varchar(500) default NULL,
  `eid` int(11) NOT NULL,
  PRIMARY KEY  (`cid`),
  KEY `eid` (`eid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `comment`
-- 

INSERT INTO `comment` (`cid`, `author`, `message`, `eid`) VALUES 
(1, 'anonymous', 'Esto es una prueba de comentario', 1),
(2, 'segundo', 'Se viene el segundo', 1),
(3, 'anastacio', 'Qué lindo nombre que tengo eh!?', 1),
(4, 'quien?', 'qué pasa cuando hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios ?', 1),
(5, 'quien2?', 'qué pasa cuando hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios hay muchos comentatios ?', 1),
(6, 'anonymous', 'Prueba de comentario', 2),
(7, 'cuak', '... ya llega el pato...cuak...', 2),
(8, 'qué te pasa che!?', 'porqué no te vas un poco a la m.....', 2);
