package myblog.dao;

import java.util.List;
import myblog.BlogEntry;

public interface BlogEntryDAO {

	public List getMostRecentBlogEntries() throws DataAccessException;
	
	public BlogEntry getBlogEntryById(int id) throws DataAccessException;

	public void createBlogEntry(BlogEntry entry) throws DataAccessException;

	public void updateBlogEntry(BlogEntry entry) throws DataAccessException;
	
	public void deleteBlogEntry(BlogEntry entry) throws DataAccessException;
	
}
