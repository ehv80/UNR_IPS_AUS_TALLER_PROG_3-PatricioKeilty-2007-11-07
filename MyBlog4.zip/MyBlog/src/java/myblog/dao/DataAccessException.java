package myblog.dao;

public class DataAccessException extends Exception {

	public DataAccessException(){
		super();
	}

	public DataAccessException(Throwable e){
		super(e);
	}
	
	public DataAccessException(String message, Throwable e){
		super(message,e);
	}

	private static final long serialVersionUID = 8495610954825179210L;

}
