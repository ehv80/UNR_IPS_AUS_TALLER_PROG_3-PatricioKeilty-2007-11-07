package myblog.dao;

import java.util.List;
import myblog.Comment;

public interface CommentDAO {

	public List getCommentsByBlogEntryId(int id) throws DataAccessException;

	public void createCommentForBlogEntryId(int id, Comment comment) throws DataAccessException;

	public void updateComment(Comment comment) throws DataAccessException;
	
	public void deleteComment(Comment comment) throws DataAccessException;
	
	public void deleteCommentsForBlogEntryId(int id) throws DataAccessException;
}
