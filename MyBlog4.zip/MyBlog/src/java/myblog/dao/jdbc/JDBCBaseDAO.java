package myblog.dao.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

import myblog.dao.DataAccessException;

public abstract class JDBCBaseDAO {

	protected Connection getConnection() throws DataAccessException {
		Connection conn;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/myblog?user=root");
		} catch (Exception e) {
			throw new DataAccessException("Error obteniendo conexi�n a DB", e);
		}
		return conn;
	}

}
