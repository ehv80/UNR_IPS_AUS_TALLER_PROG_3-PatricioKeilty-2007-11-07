package myblog.dao.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import myblog.BlogEntry;
import myblog.Comment;
import myblog.dao.BlogEntryDAO;
import myblog.dao.DataAccessException;

public class JDBCBlogEntryDAO extends JDBCBaseDAO implements BlogEntryDAO {

	private final String entriesQuery = "SELECT * FROM blog_entry";
	private final String insertQuery = "INSERT INTO blog_entry (title, body) VALUES ('@title@', '@body@')";
	private final String deleteQuery = "DELETE FROM blog_entry WHERE eid = @eid@";

	public List getMostRecentBlogEntries() throws DataAccessException {
		List blogEntries = new ArrayList();
		Statement stmt = null;
		Connection conn = null;

		try 
		{
			conn = getConnection();
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(entriesQuery);
			while (rs.next()){
				String title = rs.getString("title");
				String body = rs.getString("body");
				int entityId = rs.getInt("eid");
				BlogEntry entry = new BlogEntry( title, body );
				entry.setId(entityId);
				blogEntries.add(entry);
			}
		} catch(Exception excepcion){
			throw new DataAccessException(excepcion);
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new DataAccessException(e);
			}
		}
		Collections.sort(blogEntries);
		return blogEntries;
	}

	public void createBlogEntry(BlogEntry entry) throws DataAccessException {
		Statement stmt = null;
		  Connection conn = null;
		  try 
		  {
		    conn = getConnection();
		    stmt = conn.createStatement();
		    String query = insertQuery.replaceAll("@title@", entry.getTitle()).
	  	        replaceAll("@body@", entry.getBody());
		    stmt.executeUpdate(query);
		  } catch(Exception excepcion){
			  throw new DataAccessException(excepcion);
		  } finally {
			  try {
		    if (stmt != null)
		    	stmt.close();
		    if (conn != null)
		    	conn.close();
			  }catch (Exception e) {
				throw new DataAccessException(e); 
			}
		  }
	}

	public void deleteBlogEntry(BlogEntry entry) throws DataAccessException {
		  Statement stmt = null;
		  Connection conn = null;
		  
		  try 
		  {
		    conn = getConnection();
		    stmt = conn.createStatement();
		    String query = deleteQuery.replaceAll("@eid@", String.valueOf(entry.getId()));
		    stmt.executeUpdate(query);
		  } catch(Exception excepcion){
		    throw new DataAccessException(excepcion);
		  } finally {
			  try {
		    if (stmt != null)
		    	stmt.close();
		    if (conn != null)
		    	conn.close();
			  }catch (Exception e) {
				throw new DataAccessException(e); 
			}
		  }
	}

	public BlogEntry getBlogEntryById(int id) throws DataAccessException {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateBlogEntry(BlogEntry entry) throws DataAccessException {
		// update database!
		  final String updateQuery = "UPDATE blog_entry set title='@title@', body='@body@' WHERE eid = @eid@";
		  
		  Statement stmt = null;
		  Connection conn = null;
		  
		  try 
		  {
		    conn = getConnection();
		    stmt = conn.createStatement();
	    	String query = updateQuery.replaceAll("@eid@", String.valueOf(entry.getId())).
	    	        replaceAll("@title@", entry.getTitle()).
	    	        replaceAll("@body@", entry.getBody());
		    stmt.executeUpdate(query);
		  } catch(Exception excepcion){
			  throw new DataAccessException(excepcion);
		  } finally {
			  try {
		    if (stmt != null)
		    	stmt.close();
		    if (conn != null)
		    	conn.close();
			  }catch (Exception e) {
				throw new DataAccessException(e); 
			}
		  }
	}

}
